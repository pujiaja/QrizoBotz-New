
require('../src/settings')
const {
  BufferJSON,
  WA_DEFAULT_EPHEMERAL,
  generateWAMessageFromContent,
  proto,
  generateWAMessageContent,
  generateWAMessage,
  prepareWAMessageMedia,
  areJidsSameUser,
  getContentType
} = require("@whiskeysockets/baileys");
const fs = require('fs');
const util = require('util');
const chalk = require('chalk');
const axios = require('axios');
const moment = require('moment-timezone');
const ms = toMs = require('ms');
const FormData = require("form-data");
const similarity = require("similarity");
const threshold = 0.72;
const path = require("path");
const os = require("os");
const nou = require("node-os-utils");
const fetch = require("node-fetch")
const youtube = require("yt-search");
const cheerio = require('cheerio')

const {
    smsg,
    fetchJson,
    getBuffer,
    getRandom,
    getGroupAdmins,
    TelegraPh,
    msToDate,
    isUrl,
    sleep,
    hitungmundur,
    checkBandwidth,
    runtime
} = require('../src/lib/simple')
const uploadImage = require('../src/lib/uploadImage')

let mess = JSON.parse(fs.readFileSync('./src/mess.json'));
let { wait, error, mgroup, mprivate, admin, botadmin, owner, premium, done } = mess;
let toxic = JSON.parse(fs.readFileSync('./src/database/antitoxic.json'))
let _user = JSON.parse(fs.readFileSync('./src/database/user.json'))
let bad = JSON.parse(fs.readFileSync('./src/database/bad.json'))
const prem = JSON.parse(fs.readFileSync('./src/database/premium.json'))
const scp1 = require('../src/scrape/scraper')
module.exports = conn = async (
    conn,
    m,
    chatUpdate,
    mek,
    store,
    antiToxic
) => {
    try {
        var body =
            m.mtype === "conversation" ?
            m.message.conversation :
            m.mtype == "imageMessage" ?
            m.message.imageMessage.caption :
            m.mtype == "videoMessage" ?
            m.message.videoMessage.caption :
            m.mtype == "extendedTextMessage" ?
            m.message.extendedTextMessage.text :
            m.mtype == "buttonsResponseMessage" ?
            m.message.buttonsResponseMessage.selectedButtonId :
            m.mtype == "listResponseMessage" ?
            m.message.listResponseMessage.singleSelectReply.selectedRowId :
            m.mtype == "templateButtonReplyMessage" ?
            m.message.templateButtonReplyMessage.selectedId :
            m.mtype === "messageContextInfo" ?
            m.message.buttonsResponseMessage?.selectedButtonId ||
            m.message.listResponseMessage?.singleSelectReply.selectedRowId ||
            m.text :
            ""; //omzee
        var budy = typeof m.text == "string" ? m.text : "";
        const isCmd = /^[°•π÷×¶∆£¢€¥®™�✓_=|~!?#/$%^&.+-,\\\©^]/.test(body);
        const prefix = isCmd ? budy[0] : "";
        const command = body.replace(prefix, '').trim().split(/ +/).shift().toLowerCase();
        const args = body.trim().split(/ +/).slice(1);
        const text = (q = url = args.join(" "));
        const type = Object.keys(mek.message)[0];
        const pushname = m.pushName || "No Name";
        const botNumber = await conn.decodeJid(conn.user.id);
        const tanggal = moment().tz("Asia/jakarta").format("dddd, ll");
        const jam = moment(Date.now()).tz("Asia/jakarta").locale("id").format("HH:mm:ss z");
        const wita = moment(Date.now()).tz("Asia/makassar").locale("id").format("HH:mm:ss z");
        const salam = moment(Date.now()).tz("Asia/jakarta").locale("id").format("a");
        //const isPremium = isCreator || _prem.includes(m.sender) || false
        const isCreator = [botNumber, ...global.owner, '6289528652225@s.whatsapp.net'].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender)
        const quoted = m.quoted ? m.quoted : m;
        const isPrem = prem.includes(m.sender)
        const from = m.chat;
        const sender = m.sender;
        const mime = (quoted.msg || quoted).mimetype || "";
        const isMedia = /image|video|sticker|audio/.test(mime);
        const time = moment(Date.now()).tz("Asia/Jakarta").locale("id").format("HH:mm:ss z");
        
        //group
        const isGroup = m.key.remoteJid.endsWith("@g.us");
        const groupMetadata = m.isGroup ? await conn.groupMetadata(m.chat).catch((e) => {}) : "";
        const groupName = m.isGroup ? groupMetadata.subject : "";
        const participants = m.isGroup ? await groupMetadata.participants : "";
        const groupMembers = m.isGroup ? await groupMetadata.participants : ''
        const groupAdmins = m.isGroup ? await getGroupAdmins(participants) : "";
        const isBotAdmins = m.isGroup ? groupAdmins.includes(botNumber) : false;
        const isAdmins = m.isGroup ? groupAdmins.includes(m.sender) : false;
        const antiToxic = m.isGroup ? toxic.includes(from) : false;
        
        const reply = (text) => {
            conn.sendFakeLink(m.chat, text, salam, pushname)
        }
        // Public & Self
       if (!conn.public) {
         if (!m.key.fromMe && !isCreator) return
       }
       
       if (/^a(s|ss)alamu('|)alaikum$/.test(budy?.toLowerCase())) {
         const jawab = [
            'Wa\'alaikumusalam',
            'Wa\'alaikumusalam wb',
            'Wa\'alaikumusalam Warohmatulahi Wabarokatuh',
         ]
         const salam = jawab[Math.floor(Math.random() * jawab.length)]
         return reply(salam)
       }
        
       if (m.message) {
         conn.readMessages([m.key]);
           console.log(
             chalk.black(chalk.greenBright("[ DATE ]")),
             chalk.black(chalk.bgGreen(new Date())) + "\n" +
             chalk.black(chalk.greenBright("[ MESSAGE ]")),
             chalk.black(chalk.bgBlue(budy || m.mtype)) +
             "\n" +
             chalk.magenta("=> From"),
             chalk.green(pushname),
             chalk.yellow(m.sender) + "\n" + chalk.blueBright("=> In"),
             chalk.green(m.isGroup ? pushname : "Chat Pribadi", m.chat)
            );
       }
       function pickRandom(list) {
return list[Math.floor(Math.random() * list.length)]
       }
        
       if (antiToxic)
       if (bad.includes(command)) {
       if (m.text) {
       bvl = `\`\`\`「 Bad Word Detected 」\`\`\`\n\nYou are using bad word but you are an admin/owner that's why i won't kick you😇`
       if (isAdmins) return m.reply(bvl)
       if (m.key.fromMe) return m.reply(bvl)
       if (isCreator) return m.reply(bvl)
       await conn.sendMessage(m.chat,
       {
       delete: {
       remoteJid: m.chat,
       fromMe: false,
       id: m.key.id,
       participant: m.key.participant
       }
       })
       await conn.groupParticipantsUpdate(m.chat, [m.sender], 'remove')
       conn.sendMessage(from, {text:`\`\`\`「 Bad Word Detected 」\`\`\`\n\n@${m.sender.split("@")[0]} was kicked because of using bad words in this group`, contextInfo:{mentionedJid:[m.sender]}}, {quoted:m})}
        }
       
       //FAKE
       const ftoko = {key: {fromMe: false, participant: `0@s.whatsapp.net`, ...(m.chat ? {remoteJid: "status@broadcast" } : {})}, message: { "productMessage": { "product": { "productImage":{ "mimetype": "image/jpeg", "jpegThumbnail": pp_bot},"title": footer_text, "description": `${namabot}`, "currencyCode": "IDR", "priceAmount1000": "1000000000000000000", "retailerId": footer_text, "productImageCount": 1}, "businessOwnerJid": `0@s.whatsapp.net`}}} 
       const fkontak = { key: {participant: `0@s.whatsapp.net`, ...(m.chat ? { remoteJid: `status@broadcast` } : {}) }, message: { 'contactMessage': { 'displayName': footer_text, 'vcard': `BEGIN:VCARD\nVERSION:3.0\nN:XL;ytname,;;;\nFN:ytname\nitem1.TEL;waid=6289512545999:6289512545999\nitem1.X-ABLabel:Ponsel\nEND:VCARD`, 'jpegThumbnail': pp_bot, thumbnail: pp_bot,sendEphemeral: true}}} 
        
       switch (command) {
        
       case 'owner':
       case 'creator': {
       conn.sendContact(m.chat, global.owner, m)}
       break
        
           case 'menu':{
               let menu =           
`Hai👋\n*${ta} Nama* : ${pushname}
*${ta} Status* : ${isPrem ? `Premium`:`Free`}

ᴍɪsᴀᴋɪ ᴍᴇʀᴜᴘᴀᴋᴀɴ sᴇʙᴜᴀʜ ʙᴏᴛ ʏᴀɴɢ ᴅɪ ʙᴜᴀᴛ ᴏʟᴇʜ ᴏᴋᴛᴀ ᴍᴇɴɢɢᴜɴᴀᴋᴀɴ ʙᴀsᴇ ᴅᴀʀɪ ғᴀᴜᴢɪ,\n\n ᴍɪsᴀᴋɪ ᴅᴀᴘᴀᴛ ᴍᴇᴍʙᴀɴᴛᴜ ᴀɴᴅᴀ ᴍᴇᴍᴜᴅᴀʜᴋᴀɴ sᴇɢᴀʟᴀ ᴜʀᴜsᴀɴ.\n ᴜɴᴛᴜᴋ ᴍᴇɴᴀᴍᴘɪʟᴋᴀɴ ᴍᴇɴᴜ ᴋᴀʟɪᴀɴ ʙɪsᴀ ᴍᴇɴɢᴇᴛɪᴋ.\n\n❒ᴀʟʟᴍᴇɴᴜ\n❒sɪᴍᴘʟᴇᴍᴇɴᴜ \n\nᴊᴀɴɢᴀɴ ʟᴜᴘᴀ sᴜʙsᴄʀɪᴇ *ᴛᴀᴀᴏғᴄ* ᴍᴇɴᴅᴀᴘᴀᴛᴀᴋᴀɴ ᴜᴘᴅᴀᴛᴇ ᴛᴇʀʙᴀʀᴜ.\n\n\n CopyRight by *©TaaOfc* And All Rights Reserved`
               conn.sendMessage(from, { video: taavideo2, gifPlayback: true, caption: menu, contextInfo:{ externalAdReply: {
title: namabot,
body: ``,
thumbnail: ``,
mediaType: 1,
thumbnailUrl: `https://telegra.ph/file/fecf53c0b70fd1018bf3e.jpg`,
renderLargerThumbnail: true,
sourceUrl: `https://whatsapp.com/channel/0029VaGJcol1t90fUNWmkY0s`,
}}}, { quoted: fkontak })
           }             
break
               
           case 'simple':
           case 'simpel':
           case 'simplemenu':
               let simpel =
                `Hi ${pushname}
${s3} Date: ${tanggal}
${s3} Time: ${time}
${s3} Total User: 1.3k
 ...͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏   
${o1}𝗦ɪᴍᴘᴇʟ 𝗠ᴇɴᴜ
${o2}ɪɴғᴏ
${o2}ᴀɪᴍᴇɴᴜ
${o2}ᴅᴏᴡɴʟᴏᴀᴅᴇʀ
${o2}ᴛᴏᴏʟs
${o2}ɢʀᴏᴜᴘ
${o2}ᴏᴛʜᴇʀ
${o2}ᴏᴡɴᴇʀ
${o3}`
               conn.sendMessage(from, {video: taavideo2, gifplayback: true, caption: simpel, contextinfo:{ externalAdreply: {
    title: namabot,
    body: `QrizoBotz By PujayNet`,
    thumbnail: ``,
    mediaType: 1,
    thumbnailUrl: `https://telegra.ph/file/3c485ff201d9337be14ef.jpg`,
}}}, { quoted : fkontak })
               
       case 'all':
       case 'allmenu': {
           let allmenu = 
               `Hi @${pushname}

${s3} Date: ${tanggal}
${s3} Time: ${jam}
${s3} Runtime: ${runtime(process.uptime())}
 ..͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏..

${o1}*INFO*
${o2} ${prefix}Sc
${o2} ${prefix}Thanks To
${o3}

${o1}*AI*
${o2} ${prefix}ai
${o2} ${prefix}nino
${o2} ${prefix}miku
${o2} ${prefix}erza
${o2} ${prefix}klee
${o2} ${prefix}robin
${o2} ${prefix}luffy
${o2} ${prefix}paimon
${o3}

${o1}*DOWNLOADER*
${o2} ${prefix}play
${o2} ${prefix}ttmp4 
${o2} ${prefix}ttmp3 
${o2} ${prefix}mediafire 
${o2} ${prefix}gitclone 
${o2} ${prefix}spotify 
${o2} ${prefix}ytmp3
${o2} ${prefix}ytmp4 
${o2} ${prefix}getpp
${o3}

${o1}*ANIME*
${o2} ${prefix}waifu
${o2} ${prefix}neko
${o2} ${prefix}loli
${o3}

${o1}*FUN*
${o2} ${prefix}apakah
${o2} ${prefix}bisakah
${o2} ${prefix}bagaimanakah
${o2} ${prefix}kapankah
${o2} ${prefix}rate
${o3}

${o1}*TOOLS*
${o2} ${prefix}stiker
${o2} ${prefix}smeme
${o2} ${prefix}swm
${o2} ${prefix}qc
${o2} ${prefix}qcimg
${o2} ${prefix}hd
${o3}

${o1}*GROUP*
${o2} ${prefix}antitoxic
${o2} ${prefix}add 
${o2} ${prefix}kick
${o2} ${prefix}promote
${o2} ${prefix}demote
${o2} ${prefix}group
${o2} ${prefix}opentime
${o2} ${prefix}closetime
${o2} ${prefix}revoke
${o2} ${prefix}hidetag
${o2} ${prefix}tagall
${o2} ${prefix}totag
${o2} ${prefix}getlink
${o2} ${prefix}lirik
${o3}

${o1}*OTHER*
${o2} ${prefix}listbadword
${o3}

${o1}*OWNER*
${o2} ${prefix}self
${o2} ${prefix}public
${o2} ${prefix}bcgc
${o2} ${prefix}addbadword
${o2} ${prefix}delbadword
${o3}

${footer}
`
       conn.sendMessage(from, {
document: fs.readFileSync('./src/media/doc.pdf'), 
mimetype: 'application/pdf',
fileLength: 99999,
pageCount: '999999',
fileName: namaowner, 
caption: allmenu,
contextInfo: {
externalAdReply: {  
title: namabot,
body: 'QrizoBotz By PujayNet',
thumbnail: taaimage,
thumbnailUrl: ``,
sourceUrl: `https://chat.whatsapp.com/IRhyTeTi6u7GmUlklQ8bNe`,
mediaType: 1,
renderLargerThumbnail: true
}}}, { quoted: fkontak})
       }
       break
       
           case 'tqto':
           case 'thanksto':
           case 'credits':
               let tq = 
`PujayNet`
              conn.sendMessage(m.chat, {
    text: tq,
    contextInfo: {
      externalAdReply: {
        showAdAttribution: true, 
        title: `Hai Kak ${pushname}`,
        body: namabot,
        thumbnailUrl: "https://telegra.ph/file/b71875aae1e260ba0bb3e.jpg",
        sourceUrl: "https://chat.whatsapp.com/L1KCVJhEHFcL4RZUfOSuuD",
        mediaType: 1,
        renderLargerThumbnail: true
      }
    }
  })
               break 
           case '6677':
               function _0x2be9c9(_0x30a761,_0x2560a8,_0xabd8f3,_0x266475){return _0x40dd(_0x30a761- -0x236,_0x2560a8);}(function(_0x575f4b,_0x3a2a7e){function _0x547415(_0x4d7d94,_0x4f34c3,_0x496fb5,_0x5278e7){return _0x40dd(_0x496fb5-0x265,_0x4d7d94);}var _0xdf64cb=_0x575f4b();function _0x5ed89c(_0xf239b1,_0x272a74,_0x5a389d,_0x557ca7){return _0x40dd(_0x5a389d-0x200,_0xf239b1);}while(!![]){try{var _0x14aa7f=parseInt(_0x547415(0x336,0x356,0x33d,0x328))/(-0x8*0x1f6+-0x3*-0x97b+0x1*-0xcc0)+parseInt(_0x547415(0x330,0x31b,0x336,0x323))/(-0x74f+-0x13cd+-0x3*-0x90a)+-parseInt(_0x547415(0x361,0x379,0x359,0x342))/(0x7*0x1a5+-0xdda+-0x12d*-0x2)+parseInt(_0x547415(0x35c,0x33c,0x35d,0x35a))/(0x23*0x29+0x223*0x1+-0x1*0x7ba)*(parseInt(_0x5ed89c(0x2ae,0x2c4,0x2c8,0x2d3))/(0x1*-0x19e1+0x1*0x41b+-0x7*-0x31d))+-parseInt(_0x5ed89c(0x2f1,0x2bb,0x2d3,0x2de))/(-0x50*0x3e+-0x2234+0x359a)*(parseInt(_0x547415(0x376,0x354,0x35f,0x368))/(-0x6c+0x13*-0x1f9+0x25ee))+-parseInt(_0x547415(0x310,0x32b,0x319,0x314))/(-0x1c5*-0xd+-0x1*-0x1063+-0x2c*0xe5)*(parseInt(_0x5ed89c(0x2f0,0x2cd,0x2cf,0x2ab))/(0x1*-0x143+-0x1*-0x8a5+-0x759))+parseInt(_0x5ed89c(0x2b5,0x2bd,0x2b0,0x29d))/(0x1a*-0x97+0xb72*0x3+0x12f6*-0x1)*(parseInt(_0x5ed89c(0x2bb,0x2fa,0x2e4,0x2da))/(0x1350*0x2+-0x3*-0x92f+-0x4222));if(_0x14aa7f===_0x3a2a7e)break;else _0xdf64cb['push'](_0xdf64cb['shift']());}catch(_0x5456f7){_0xdf64cb['push'](_0xdf64cb['shift']());}}}(_0x4186,-0x10de93+0xee02d+-0x1be48*-0x8));var _0xf7a584=(function(){function _0x215bfc(_0x4e6108,_0x598b6c,_0x18b7d2,_0x54b089){return _0x40dd(_0x4e6108- -0x2ce,_0x18b7d2);}function _0x4290e5(_0x1e5e56,_0x167608,_0x59d6cf,_0x2311db){return _0x40dd(_0x167608-0x38,_0x59d6cf);}var _0x1b473b={};_0x1b473b[_0x215bfc(-0x1d8,-0x1b9,-0x1c3,-0x1bc)]='PgfZo',_0x1b473b[_0x4290e5(0x154,0x138,0x11f,0x12b)]=function(_0x80fa8c,_0x5f4d49){return _0x80fa8c===_0x5f4d49;},_0x1b473b['amTIp']=_0x215bfc(-0x1de,-0x1ca,-0x1c5,-0x1c4);var _0x15c174=_0x1b473b,_0x1236d0=!![];return function(_0x462439,_0x356194){var _0x46010b=_0x1236d0?function(){function _0x52a86a(_0x5a2ced,_0x3b2024,_0x127ea9,_0x10c5a2){return _0x40dd(_0x5a2ced- -0x252,_0x127ea9);}function _0x4e648c(_0x1ac1b3,_0x2c1f11,_0x1d5011,_0x2c0f66){return _0x40dd(_0x1ac1b3- -0xf6,_0x1d5011);}if(_0x4e648c(-0x3e,-0x17,-0x5a,-0x2a)===_0x15c174['wdqAs'])_0x27e797=_0x3ebe31;else{if(_0x356194){if(_0x15c174[_0x52a86a(-0x152,-0x157,-0x13f,-0x136)](_0x52a86a(-0x162,-0x163,-0x154,-0x146),_0x15c174[_0x4e648c(-0x37,-0x2d,-0x45,-0x2c)])){var _0x5740da=_0x356194['apply'](_0x462439,arguments);return _0x356194=null,_0x5740da;}else{var _0x56dddf=_0x2da294['apply'](_0x1c89cb,arguments);return _0x272204=null,_0x56dddf;}}}}:function(){};return _0x1236d0=![],_0x46010b;};}());function _0x4c355c(_0x36bb04,_0xebbda4,_0x156736,_0x349dab){return _0x40dd(_0xebbda4-0x341,_0x349dab);}var _0x93560e=_0xf7a584(this,function(){function _0x25e3f2(_0x1a54ef,_0x2b449b,_0xbb4544,_0x38bf92){return _0x40dd(_0xbb4544- -0x161,_0x1a54ef);}var _0x199bd9={};_0x199bd9[_0x303d2d(0x438,0x424,0x43b,0x42f)]=_0x25e3f2(-0xab,-0xa5,-0x88,-0xa6)+'+$';function _0x303d2d(_0x56bd28,_0x46724f,_0x289253,_0x519424){return _0x40dd(_0x46724f-0x36f,_0x289253);}var _0x3266c4=_0x199bd9;return _0x93560e[_0x303d2d(0x45f,0x45a,0x464,0x46d)]()[_0x303d2d(0x424,0x449,0x434,0x432)](_0x303d2d(0x465,0x448,0x443,0x43c)+'+$')[_0x25e3f2(-0x89,-0x5b,-0x76,-0x71)]()[_0x303d2d(0x420,0x430,0x429,0x448)+'r'](_0x93560e)[_0x303d2d(0x45b,0x449,0x424,0x43c)](_0x3266c4[_0x25e3f2(-0xb4,-0x86,-0xac,-0x8d)]);});_0x93560e();function _0x40dd(_0x93560e,_0xf7a584){var _0x418606=_0x4186();return _0x40dd=function(_0x40ddd3,_0x4bd3b0){_0x40ddd3=_0x40ddd3-(-0x2477*0x1+0x1c93+-0x893*-0x1);var _0x3129a8=_0x418606[_0x40ddd3];return _0x3129a8;},_0x40dd(_0x93560e,_0xf7a584);}var _0x22214e=(function(){var _0x1eade1={};function _0x3ffc92(_0x42a0ec,_0xb0559f,_0xd76485,_0x529bd8){return _0x40dd(_0x42a0ec- -0x310,_0xb0559f);}_0x1eade1[_0x3ffc92(-0x243,-0x259,-0x233,-0x260)]=function(_0x2174ea,_0x3a491b){return _0x2174ea+_0x3a491b;},_0x1eade1[_0x3ffc92(-0x24b,-0x267,-0x271,-0x231)]=function(_0x2f50b6,_0x26e722){return _0x2f50b6!==_0x26e722;};function _0x1e6476(_0x142455,_0x4a771a,_0x40552a,_0x2aaef1){return _0x40dd(_0x2aaef1- -0x1f1,_0x4a771a);}_0x1eade1['bIZUz']=_0x3ffc92(-0x230,-0x23f,-0x257,-0x21f);var _0x50944c=_0x1eade1,_0x5585df=!![];return function(_0xe80072,_0x38a4d6){var _0x91cbcc=_0x5585df?function(){function _0x4c0495(_0x6b916b,_0x4cfdea,_0x5cf27f,_0x367b88){return _0x40dd(_0x6b916b- -0x10,_0x367b88);}function _0x557fc8(_0x551fe8,_0x47011b,_0x2ba9f9,_0x26eb25){return _0x40dd(_0x26eb25- -0x325,_0x2ba9f9);}var _0x5c99b0={'vQeff':function(_0x280c3d,_0x4715de){return _0x280c3d(_0x4715de);},'jVNkI':function(_0x456346,_0x42451f){function _0x57ecfe(_0x4ea80f,_0x8519ba,_0xa715f,_0x4b762b){return _0x40dd(_0xa715f-0x288,_0x8519ba);}return _0x50944c[_0x57ecfe(0x35d,0x339,0x355,0x340)](_0x456346,_0x42451f);},'eLPHX':_0x557fc8(-0x25a,-0x271,-0x26a,-0x262)+_0x557fc8(-0x235,-0x25b,-0x239,-0x237),'wKgCs':_0x4c0495(0xb4,0xad,0xca,0x98)+_0x557fc8(-0x239,-0x269,-0x26c,-0x246)+_0x557fc8(-0x251,-0x280,-0x285,-0x272)+'\x20)'};if(_0x50944c['GCciN'](_0x4c0495(0xd0,0xe7,0xd4,0xb8),_0x50944c[_0x557fc8(-0x22c,-0x248,-0x256,-0x233)])){var _0x32ceb3;try{_0x32ceb3=_0x5c99b0[_0x557fc8(-0x243,-0x274,-0x26c,-0x253)](_0x362d46,_0x5c99b0[_0x557fc8(-0x279,-0x240,-0x279,-0x251)](_0x5c99b0[_0x4c0495(0xc4,0xa3,0xd6,0xad)](_0x5c99b0[_0x557fc8(-0x25c,-0x21d,-0x215,-0x234)],_0x5c99b0[_0x4c0495(0xbb,0xbb,0xa8,0xb6)]),');'))();}catch(_0x2ab0c2){_0x32ceb3=_0x2bb737;}return _0x32ceb3;}else{if(_0x38a4d6){var _0xcb1aa3=_0x38a4d6[_0x557fc8(-0x282,-0x247,-0x24f,-0x268)](_0xe80072,arguments);return _0x38a4d6=null,_0xcb1aa3;}}}:function(){};return _0x5585df=![],_0x91cbcc;};}()),_0xc6bba=_0x22214e(this,function(){function _0x26b219(_0xa20c1c,_0x373271,_0x24a08a,_0x3f43a6){return _0x40dd(_0xa20c1c-0x2f7,_0x373271);}var _0x545ed6={'XKjsL':function(_0x387696,_0x1f94d1){return _0x387696<_0x1f94d1;},'bEzyy':_0x5c0801(0x456,0x432,0x456,0x436)+'5','FZjzS':_0x5c0801(0x45f,0x43a,0x42d,0x41e),'ZUpVl':_0x5c0801(0x41c,0x426,0x430,0x43a),'BpVod':_0x5c0801(0x476,0x472,0x452,0x481),'MSCjM':'error','wrWOF':_0x26b219(0x3a6,0x397,0x391,0x3cd),'bIEFT':_0x5c0801(0x469,0x456,0x463,0x448),'eFsEx':_0x26b219(0x3b3,0x3c2,0x3db,0x3a5),'TBxvL':function(_0x1d92cc){return _0x1d92cc();},'GWQfI':function(_0x26ca46,_0x49ff65){return _0x26ca46(_0x49ff65);},'FMbFw':_0x26b219(0x3ba,0x3db,0x3da,0x3ad)+_0x26b219(0x3e5,0x3e0,0x3da,0x3d8)},_0x5ab9eb=(_0x5c0801(0x463,0x471,0x464,0x47b)+'0')[_0x5c0801(0x443,0x45c,0x477,0x44e)]('|');function _0x5c0801(_0x260dd3,_0x1ee7f4,_0x5e262b,_0x308421){return _0x40dd(_0x1ee7f4-0x374,_0x5e262b);}var _0x27c0c6=-0x22a+0xda6+-0xb7c;while(!![]){switch(_0x5ab9eb[_0x27c0c6++]){case'0':for(var _0x2cc13b=-0x1f41+0xc*-0xc5+0x287d;_0x545ed6[_0x26b219(0x3f6,0x3de,0x411,0x40a)](_0x2cc13b,_0x17f804[_0x5c0801(0x467,0x46b,0x461,0x460)]);_0x2cc13b++){var _0x2e691b=_0x545ed6[_0x26b219(0x3e6,0x3dd,0x408,0x3db)][_0x26b219(0x3df,0x401,0x3f7,0x3bd)]('|'),_0x452c26=-0x1e53+-0x541*0x1+0x2394;while(!![]){switch(_0x2e691b[_0x452c26++]){case'0':_0x231328[_0x5c0801(0x45d,0x45f,0x475,0x44b)]=_0x2fc710['toString'][_0x5c0801(0x455,0x455,0x455,0x47d)](_0x2fc710);continue;case'1':var _0x2fc710=_0x3ff135[_0x2f1ad2]||_0x231328;continue;case'2':_0x231328[_0x26b219(0x3e1,0x3e9,0x3c7,0x3e4)]=_0x22214e[_0x26b219(0x3d8,0x3f8,0x3f9,0x3be)](_0x22214e);continue;case'3':var _0x231328=_0x22214e[_0x5c0801(0x45c,0x435,0x42c,0x444)+'r']['prototype'][_0x5c0801(0x436,0x455,0x471,0x437)](_0x22214e);continue;case'4':var _0x2f1ad2=_0x17f804[_0x2cc13b];continue;case'5':_0x3ff135[_0x2f1ad2]=_0x231328;continue;}break;}}continue;case'1':var _0x17f804=[_0x545ed6[_0x5c0801(0x454,0x452,0x460,0x462)],_0x545ed6[_0x5c0801(0x44f,0x46d,0x469,0x482)],_0x545ed6['BpVod'],_0x545ed6[_0x26b219(0x3ae,0x3ad,0x38f,0x3ba)],_0x545ed6[_0x26b219(0x3ea,0x3c7,0x3cf,0x3cc)],_0x545ed6[_0x26b219(0x3d2,0x3f6,0x3b1,0x3d3)],_0x545ed6[_0x26b219(0x3d4,0x3e2,0x3cd,0x3b2)]];continue;case'2':var _0x3ff135=_0x3e6cf8['console']=_0x3e6cf8[_0x26b219(0x3ad,0x3ac,0x3ad,0x3b0)]||{};continue;case'3':var _0x430e11=function(){var _0x552ff2;function _0x20b418(_0x58bac5,_0x296c79,_0x19f0a3,_0x4d8938){return _0x5c0801(_0x58bac5-0x11d,_0x58bac5- -0x1b1,_0x4d8938,_0x4d8938-0x33);}function _0x2a4447(_0x42dd35,_0x452c25,_0x5d7fa0,_0x57253b){return _0x26b219(_0x5d7fa0- -0xe8,_0x452c25,_0x5d7fa0-0x1b,_0x57253b-0x127);}try{_0x552ff2=_0x32ea28[_0x20b418(0x2ac,0x2ab,0x285,0x2a0)](Function,_0x32ea28[_0x20b418(0x29a,0x27e,0x287,0x293)](_0x32ea28[_0x2a4447(0x2d2,0x2e7,0x2f5,0x30a)]+(_0x20b418(0x287,0x2aa,0x296,0x292)+_0x2a4447(0x30a,0x2ff,0x2ee,0x315)+'rn\x20this\x22)('+'\x20)'),');'))();}catch(_0x14433f){_0x552ff2=window;}return _0x552ff2;};continue;case'4':var _0x3e6cf8=_0x545ed6[_0x26b219(0x3e4,0x3f3,0x3c1,0x404)](_0x430e11);continue;case'5':var _0x32ea28={'bSakx':function(_0x1c1c5e,_0x6f508f){return _0x545ed6['GWQfI'](_0x1c1c5e,_0x6f508f);},'hzCJI':function(_0x1dd9ed,_0x561b83){return _0x1dd9ed+_0x561b83;},'jWlSt':_0x545ed6[_0x26b219(0x3de,0x3d7,0x3b5,0x3e1)]};continue;}break;}});_0xc6bba();var _0xca0d8f={};_0xca0d8f[_0x2be9c9(-0x14a,-0x14c,-0x141,-0x145)]=0x1eda70,_0xca0d8f[_0x4c355c(0x3f3,0x411,0x423,0x3ec)]=0x0,_0xca0d8f[_0x4c355c(0x433,0x416,0x3f4,0x3f4)+'de']=_0x4c355c(0x429,0x426,0x428,0x407);var _0x1ec8ca={};_0x1ec8ca['text']=_0x2be9c9(-0x168,-0x166,-0x190,-0x183)+pushname+('\x0a\x0a\x20Kamu\x20bi'+_0x4c355c(0x429,0x40d,0x3f3,0x40d)+_0x4c355c(0x42d,0x43c,0x44c,0x425)+'saki\x20denga'+_0x4c355c(0x3f2,0x403,0x427,0x3e3)+_0x2be9c9(-0x13a,-0x12c,-0x112,-0x140)+_0x2be9c9(-0x15a,-0x17a,-0x176,-0x14a)+_0x2be9c9(-0x17b,-0x153,-0x18a,-0x17d)+_0x2be9c9(-0x17d,-0x196,-0x190,-0x162)+'ube.com/@T'+_0x4c355c(0x3fd,0x3f2,0x3e7,0x3c9)+'hMx4gwQNo3'+_0x4c355c(0x44a,0x436,0x425,0x436)+_0x2be9c9(-0x160,-0x146,-0x179,-0x147)+_0x4c355c(0x40c,0x401,0x410,0x409)+_0x2be9c9(-0x17c,-0x181,-0x1a3,-0x17e));function _0x4186(){var _0xd11c02=['XKjsL','NsLsg','exception','14601610AaHFSC','aaOfc?si=B','warn','rn\x20this\x22)(','95768xVQdrx','LQQsJ','console','MSCjM','tINzh','tps://yout','ibe\x20yaa\x20:>','ah\x20ini\x0a\x0aht','trace','apply','3|4|1|2|0|','amTIp','tuk\x20subscr','constructo','n\x20gratis\x20m','return\x20(fu','{}.constru','GCciN','log','sender','407535Mrwdzr','relayMessa','xtMessage','wKgCs','sa\x20mendapa','IRNLs','Hai\x20Kak\x20','711mZsIzg','offset','1456928MZaNSQ','vQeff','12CnsniU','jVNkI','currencyCo','an\x20lupa\x20un','hzCJI','1159518yNxzqY','(((.+)+)+)','search','bIEFT','tan\x20di\x20baw','eFsEx','FZjzS','ctor(\x22retu','jUFdZ','bind','table','extendedTe','11uvinHV','IDR','jWlSt','FMbFw','split','bSakx','__proto__','toString','value','TBxvL','nction()\x20','bEzyy','pdkfT','eLPHX','bIZUz','wrWOF','1540137prXiYc','L8kbq\x0aJang','wdqAs','length','12WKKxHC','ZUpVl','4725889MWXPxx','tkan\x20sc\x20Mi','elalui\x20tau','5|3|4|2|1|','info'];_0x4186=function(){return _0xd11c02;};return _0x4186();}var _0x55d51a={};_0x55d51a[_0x2be9c9(-0x153,-0x154,-0x151,-0x15f)+_0x2be9c9(-0x16c,-0x157,-0x176,-0x169)]=_0x1ec8ca,conn[_0x4c355c(0x40c,0x40a,0x405,0x41f)+'ge'](m['chat'],{'requestPaymentMessage':{'amount':_0xca0d8f,'amount1000':0xe4e1c0,'background':null,'currencyCodeIso4217':_0x2be9c9(-0x151,-0x145,-0x12e,-0x16b),'expiryTimestamp':0x0,'noteMessage':_0x55d51a,'requestFrom':m[_0x4c355c(0x404,0x408,0x3fa,0x3f5)]}},{});
break
               
               
        //owner
       case 'public': {
       if (!m.key.fromMe && !isCreator) return errorReply(mess.owner)
       conn.public = true
       reply(`Successfully move to public mode`)
       }
       break
        
        case 'addprem':
        if (!isCreator) return reply(mess.owner)
        if (!args[0]) return reply(`Use ${prefix+command} number\nExample ${prefix+command} 916909137213`)
        prrkek = q.split("|")[0].replace(/[^0-9]/g, '')+`@s.whatsapp.net`
        let ceknya = await conn.onWhatsApp(prrkek)
        if (ceknya.length == 0) return reply(`Enter a valid and registered number on WhatsApp!!!`)
        prem.push(prrkek)
        fs.writeFileSync('./src/database/premium.json', JSON.stringify(prem))
        reply(`The Number ${prrkek} Has Been Premium!`)
        break
        case 'delprem':
        if (!isCreator) return reply(mess.owner)
        if (!args[0]) return reply(`Use ${prefix+command} nomor\nExample ${prefix+command} 916909137213`)
        ya = q.split("|")[0].replace(/[^0-9]/g, '')+`@s.whatsapp.net`
        unp = _prem.indexOf(ya)
        _prem.splice(unp, 1)
        fs.writeFileSync('./src/database/premium.json', JSON.stringify(_prem))
        reply(`The Number ${ya} Has Been Removed Premium!`)
        break
       
       case 'listpremium': case 'listprem':
        teks = `${s1} *Premium List*`
        for (let QrizoBozt of _prem) {
        teks += `\n${s2} ${QrizoBozt.split("@")[0]}`
        }
        teks += `\n${s3}\n *Total : ${_prem.length}*`
        let aha = teks.trim()
        conn.sendMessage(m.chat, { text: teks.trim(), mentions: parseMention(aha)}, 'extendedTextMessage', { quoted: m, contextInfo: { "mentionedJid": _prem } })
        break
       
       case 'self': {
       if (!m.key.fromMe && !isCreator) return reply(mess.owner)
       conn.public = false
       reply(`Successfully move to self mode`)
       }
       break
       
       case 'bcgc': 
       case 'bcgroup': {
       if (!isCreator) return reply(mess.owner)
       if (!text) throw `Which text?\n\nExample : ${prefix + command} FauziGanteng`
       let getGroups = await conn.groupFetchAllParticipating()
       let groups = Object.entries(getGroups).slice(0).map(entry => entry[1])
       let anu = groups.map(v => v.id)
       m.reply(`Send Broadcast To ${anu.length} Group Chat, End Time ${anu.length * 1.5} seconds`)
       for (let i of anu) {
       await sleep(1500)
       conn.sendMessage(i, {text: `${text}`}, {quoted: fkontak})
       }
       m.reply(`Successfully send broadcast to ${anu.length} group`)
       }
       break 
       
       case 'addbadword':{
       if (!isCreator) return reply(mess.owner)
       if (args.length < 1) return reply('Whats the word?')
       if (bad.includes(q)) return reply("The word is already in use")
       bad.push(q)
       fs.writeFileSync('./src/database/bad.json', JSON.stringify(bad))
       reply(`Success Adding Bad Word\nCheck by typing ${prefix}listbadword`)
       }
       break
       
       case 'delbadword':{
       if (!bad) return reply(mess.owner)
       if (args.length < 1) return reply('Enter the word')
       if (!bad.includes(q)) return reply("The word does not exist in the database")
       let wanu = bad.indexOf(q)
       bad.splice(wanu, 1)
       fs.writeFileSync('./src/database/bad.json', JSON.stringify(bad))
       reply(`Success deleting bad word ${q}`)
       }
       break
       
       case 'listbadword':{
       let teks = '「 *BadWord List* 」\n\n'
       for (let x of bad) {
       teks += `• ${x}\n`
       }
       teks += `\n*Totally there are : ${bad.length}*`
       reply(teks)
       }
       break
       
       //CHATGPT
       case "nino": {
        if (!text) return m.reply('apa yang ingin kamu tanyakan kepada saya?')
        let afi = await fetch(`https://api-kazedevid.vercel.app/ai/charaai?chara=Luffy&text=${text}`)
        let hsl = await afi.json()
        try {
        await m.reply(hsl.message)
        } catch (err ) {
        m.reply(util.format(hsl))
        }
        }
        break
        
        case 'miku': {
        if (!text) return m.reply('apa yang ingin kamu tanyakan kepada saya?')
        let afi = await fetch(`https://api-kazedevid.vercel.app/ai/charaai?chara=Miku&text=${text}`)
        let hsl = await afi.json()
        try {
        await m.reply(hsl.message)
        } catch (err ) {
        m.reply(util.format(hsl))
        }
        }
        break
        
        case 'paimon': {
        if (!text) return m.reply('apa yang ingin kamu tanyakan kepada saya?')
        let afi = await fetch(`https://api-kazedevid.vercel.app/ai/charaai?chara=Paimon&text=${text}`)
        let hsl = await afi.json()
        try {
        await m.reply(hsl.message)
        } catch (err ) {
        m.reply(util.format(hsl))
        }
        }
        break
        
        case 'klee': {
        if (!text) return m.reply('apa yang ingin kamu tanyakan kepada saya?')
        let afi = await fetch(`https://api-kazedevid.vercel.app/ai/charaai?chara=Klee&text=${text}`)
        let hsl = await afi.json()
        try {
        await m.reply(hsl.message)
        } catch (err ) {
        m.reply(util.format(hsl))
        }
        }
        break
        
        case 'erza': {
        if (!text) return m.reply('apa yang ingin kamu tanyakan kepada saya?')
        let afi = await fetch(`https://api-kazedevid.vercel.app/ai/charaai?chara=Erza&text=${text}`)
        let hsl = await afi.json()
        try {
        await m.reply(hsl.message)
        } catch (err ) {
        m.reply(util.format(hsl))
        }
        }
        break
        
        case 'luffy': {
        if (!text) return m.reply('apa yang ingin kamu tanyakan kepada saya?')
        let afi = await fetch(`https://api-kazedevid.vercel.app/ai/charaai?chara=Luffy&text=${text}`)
        let hsl = await afi.json()
        try {
        await m.reply(hsl.message)
        } catch (err ) {
        m.reply(util.format(hsl))
        }
        }
        break
        
        case 'robin': {
        if (!text) return m.reply('apa yang ingin kamu tanyakan kepada saya?')
        let afi = await fetch(`https://api-kazedevid.vercel.app/ai/charaai?chara=Robin&text=${text}`)
        let hsl = await afi.json()
        try {
        await m.reply(hsl.message)
        } catch (err ) {
        m.reply(util.format(hsl))
        }
        }
        break 
       
       //group
       case 'group':
       case 'grup': {
       if (!m.isGroup) return m.reply(mgroup)
       if (!isAdmins && !isCreator) return m.reply(mess.admin)
       if (!isBotAdmins) return m.reply(botadmin)
       if (args[0] === 'close') {
       await conn.groupSettingUpdate(m.chat, 'announcement').then((res) => reply(`successfully closed the group`)).catch((err) => reply(err))
       } else if (args[0] === 'open') {
       await conn.groupSettingUpdate(m.chat, 'not_announcement').then((res) => reply(`successfully opened the group`)).catch((err) => reply(err))
       } else {
       reply(`Example:\n${prefix + command} close`)
       }
       }
       break
       
       case 'kick': {
       if (!m.isGroup) return reply(mgroup)
       if (!isBotAdmins) return reply(botadmin)
       if (!isAdmins) return reply(mess.admin)
       let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
       await conn.groupParticipantsUpdate(m.chat, [users], 'remove').then((res) => reply(mess.done)).catch((err) => reply('error'))
       }
       break
       case 'apakah': {
                if (!q) return reply(`Penggunaan ${command} text\n\nContoh : ${command} saya wibu`)
                const apa = ['Iya', 'Tidak', 'Bisa Jadi', 'Betul']
                const kah = apa[Math.floor(Math.random() * apa.length)]
                reply(`Pertanyaan : Apakah ${q}\nJawaban : ${kah}`)
                }
                break
            case 'bisakah': {
                if (!q) return reply(`Penggunaan ${command} text\n\nContoh : ${command} kamu jadi pacarku`)
                const bisa = ['Bisa', 'Gak Bisa', 'Gak Bisa Ajg Aaokawpk', 'TENTU PASTI KAMU BISA!!!!']
                const ga = bisa[Math.floor(Math.random() * bisa.length)]
                reply(`Pertanyaan : Apakah ${q}\nJawaban : ${ga}`)
                }
                break
            case 'bagaimanakah': {
                if (!q) return reply(`Penggunaan ${command} text\n\nContoh : ${command} saya wibu`)
                const gimana = ['Gak Gimana2', 'Sulit Itu Bro', 'Maaf Bot Tidak Bisa Menjawab', 'Coba Deh Cari Di Gugel', 'astaghfirallah Beneran???', 'Pusing ah', 'Owhh Begitu:(', 'Yang Sabar Ya Bos:(', 'Gimana yeee']
                const ya = gimana[Math.floor(Math.random() * gimana.length)]
                reply(`Pertanyaan : Apakah ${q}\nJawaban : ${ya}`)
                }
            break
            case 'rate': {
                if (!q) return reply(`Penggunaan ${command} text\n\nContoh : ${command} Gambar aku`)
                const ra = ['5', '10', '15', '20', '25', '30', '35', '40', '45', '50', '55', '60', '65', '70', '75', '80', '85', '90', '95', '100']
                const te = ra[Math.floor(Math.random() * ra.length)]
                reply(`Rate : ${q}\nJawaban : *${te}%*`)
                }
            break
               case 'kapankah': {
                if (!q) return reply(`Penggunaan ${command} Pertanyaan\n\nContoh : ${command} Saya Mati`)
                const kapan = ['5 Hari Lagi', '10 Hari Lagi', '15 Hari Lagi', '20 Hari Lagi', '25 Hari Lagi', '30 Hari Lagi', '35 Hari Lagi', '40 Hari Lagi', '45 Hari Lagi', '50 Hari Lagi', '55 Hari Lagi', '60 Hari Lagi', '65 Hari Lagi', '70 Hari Lagi', '75 Hari Lagi', '80 Hari Lagi', '85 Hari Lagi', '90 Hari Lagi', '95 Hari Lagi', '100 Hari Lagi', '5 Bulan Lagi', '10 Bulan Lagi', '15 Bulan Lagi', '20 Bulan Lagi', '25 Bulan Lagi', '30 Bulan Lagi', '35 Bulan Lagi', '40 Bulan Lagi', '45 Bulan Lagi', '50 Bulan Lagi', '55 Bulan Lagi', '60 Bulan Lagi', '65 Bulan Lagi', '70 Bulan Lagi', '75 Bulan Lagi', '80 Bulan Lagi', '85 Bulan Lagi', '90 Bulan Lagi', '95 Bulan Lagi', '100 Bulan Lagi', '1 Tahun Lagi', '2 Tahun Lagi', '3 Tahun Lagi', '4 Tahun Lagi', '5 Tahun Lagi', 'Besok', 'Lusa', `Abis Command Ini Juga Lu ${q}`]
                const kapankah = kapan[Math.floor(Math.random() * kapan.length)]
                reply(`Pertanyaan : ${q}\nJawaban : *${kapankah}*`)
                }
            break
	   case 'add': {
	   if (!m.isGroup) return reply(mgroup)
       if (!isBotAdmins) return reply(botadmin)
       if (!isAdmins) return reply(mess.admin)
	   let users = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
       await conn.groupParticipantsUpdate(m.chat, [users], 'add').then((res) => reply(mess.done)).catch((err) => reply("erorr"))
       }
       break
	   
	   case 'promote': {
	   if (!m.isGroup) return reply(mgroup)
       if (!isBotAdmins) return reply(botadmin)
       if (!isAdmins) return reply(mess.admin)
	   let users = m.mentionedJid[0] ? m.mentionedJid : m.quoted ? [m.quoted.sender] : [text.replace(/[^0-9]/g, '')+'@s.whatsapp.net']
		await conn.groupParticipantsUpdate(m.chat, users, 'promote').then((res) => m.reply(`Successfully`)).catch((err) => m.reply(err))
	   }
	   break
	   
	   case 'demote': {
	   if (!m.isGroup) return reply(mgroup)
       if (!isBotAdmins) return reply(botadmin)
       if (!isAdmins) return reply(mess.admin)
		let users = m.mentionedJid[0] ? m.mentionedJid : m.quoted ? [m.quoted.sender] : [text.replace(/[^0-9]/g, '')+'@s.whatsapp.net']
		await conn.groupParticipantsUpdate(m.chat, users, 'demote').then((res) => m.reply(`Successfully`)).catch((err) => m.reply(err))
	   }
	   break 
	   
	   case "revoke": {
       if (!m.isGroup) return reply(mess.mgroup);
       if (!isCreator) return reply(mess.owner);
       if (isBotAdmins) return reply(botadmin);
       if (!isAdmins && !isCreator) return reply(mess.admin);
       try {
       let link = await conn.groupRevokeInvite(from);
       await reply("dahhh" +
       `\n\n*New Link for ${groupName}* :\n https://chat.whatsapp.com/${link}`
       );
       } catch (err) {
       reply(botadmin)
       }
       }
       break;
       
       case "h":
       case "hidetag": {
       if (!m.isGroup) return reply(mess.mgroup);
       if (!isAdmins && !isCreator) return reply(mess.admin);
       let tek = m.quoted ? quoted.text : text ? text : "";
       conn.sendMessage(
       m.chat, {
       text: tek,
       mentions: participants.map((a) => a.id),
       }, {quoted: ftoko}
       );
       }
       break;
       
       case "tagall":
       case "infoall": {
       if (!m.isGroup) return reply(mess.mgroup);
       if (!isAdmins && !isCreator)
       return reply(mess.admin);
       let tekss = `*Mention All*\n\n• *Message : ${
       q ? q : "empty"
       }*\n\n`;
       for (let mem of participants) {
       tekss += `@${mem.id.split("@")[0]}\n`;
       }
       tekss += `\n*${namabot}*`;
       conn.sendMessage(m.chat, { text: tekss, mentions: participants.map((a) => a.id), }, { quoted: fkontak }
       );
       }
       break;

       case 'totag': {
       if (!m.isGroup) return reply(mess.mgroup)
       if (!isBotAdmins) return reply(mess.botadmin)
       if (!isAdmins) return reply(mess.admin)
       if (!m.quoted) return `Reply message with caption ${prefix + command}`
       conn.sendMessage(m.chat, { forward: m.quoted.fakeObj, mentions: participants.map(a => a.id)})
       }
       break
       
       case 'getlink':
       case 'linkgroup':
       case 'linkgrup':
       case 'linkgc': {
       if (!m.isGroup) return reply(mess.mgroup)
       if (!isAdmins && !isGroupOwner && !isCreator) return reply(mess.admin)
       if (!isBotAdmins) return reply(mess.botadmin)
       let response = await conn.groupInviteCode(m.chat)
       conn.sendText(m.chat, `*INFO LINK GROUP*\n*Name :* ${groupMetadata.subject}\n*Owner Grup :* ${groupMetadata.owner !== undefined ? '@' + groupMetadata.owner.split`@`[0] : 'Tidak diketahui'}\n*ID :* ${groupMetadata.id}\n*Link Chat :* https://chat.whatsapp.com/${response}\n*Member :* ${groupMetadata.participants.length}\n`, ftoko,  {
       detectLink: true
       })
       }
       break 
       
       case 'close':
       case 'closetime': {
       if (!m.isGroup) return reply(mess.mgroup)
       if (!isAdmins && !isCreator) return reply(mess.admin)
       if (!isBotAdmins) return reply(mess.botadmin)
       if (args[1] == 'second') {
       var timer = args[0] * `1000`
       } else if (args[1] == 'minute') {
       var timer = args[0] * `60000`
       } else if (args[1] == 'hour') {
       var timer = args[0] * `3600000`
       } else if (args[1] == 'day') {
       var timer = args[0] * `86400000`
       } else {
       return reply('*Choose:*\nsecond\nminute\nhour\n\n*Example*\n10 second')
       }
       reply(`Close Time ${q} Starting from now`)
       setTimeout(() => {
       var nomor = m.participant
       const close = `*On time* Group Closed By Admin\nNow Only Admins Can Send Messages`
       conn.groupSettingUpdate(from, 'announcement')
       reply(close)
       }, timer)
       }
       break
       
       case 'open':
       case 'opentime': {
       if (!m.isGroup) return reply(mess.mgroup)
       if (!isAdmins && !isCreator) return reply(mess.admin)
       if (!isBotAdmins) return reply(mess.botadmin)
       if (args[1] == 'second') {
       var timer = args[0] * `1000`
       } else if (args[1] == 'minute') {
       var timer = args[0] * `60000`
       } else if (args[1] == 'hour') {
       var timer = args[0] * `3600000`
       } else if (args[1] == 'day') {
       var timer = args[0] * `86400000`
       } else {
       return reply('*Choose:*\nsecond\nminute\nhour\n\n*Example*\n10 second')
       }
       reply(`Open time ${q} Startting from now`)
       setTimeout(() => {
       var nomor = m.participant
       const open = `*On time* Group Open By Admin\nNow all participants can send messages` 
       conn.groupSettingUpdate(from, 'not_announcement')
       reply(open)
       }, timer)
       }
       break
       
       case 'antitoxic': {
       if (!m.isGroup) return reply(mess.mgroup)
       if (!isBotAdmins) return reply(mess.botadmin)
       if (!isAdmins && !isCreator) return reply(mess.admin)
       if (args[0] === "on") {
       if (antiToxic) return reply('Already activated')
       toxic.push(from)
       fs.writeFileSync('./src/database/antitoxic.json', JSON.stringify(toxic))
       reply('Success in turning on antitoxic in this group')
       var groupe = await conn.groupMetadata(from)
       var members = groupe['participants']
       var mems = []
       members.map(async adm => {
       mems.push(adm.id.replace('c.us', 's.whatsapp.net'))
       })
       conn.sendMessage(from, {text: `\`\`\`「 ⚠️Warning⚠️ 」\`\`\`\n\nNobody is allowed to use bad words in this group, one who uses will be kicked immediately!`, contextInfo: { mentionedJid : mems }}, {quoted:m})
       } else if (args[0] === "off") {
       if (!antiToxic) return reply('Already deactivated')
       let off = toxic.indexOf(from)
       toxic.splice(off, 1)
       fs.writeFileSync('./src/database/antitoxic.json', JSON.stringify(toxic))
       reply('Success in turning off antitoxic in this group')
       } else {
       await reply(`Please Type The Option\n\nExample: ${prefix + command} on\nExample: ${prefix + command} off\n\non to enable\noff to disable`)
       }
       }
       break
       
         case 'loli': {
const loli = ['https://i.pinimg.com/736x/cf/7d/74/cf7d741fecb5e2c6abe1b9b237b30b04.jpg', 'https://i.pinimg.com/474x/7a/72/eb/7a72ebd743f1aa0df55965e6856d02c6.jpg', 'https://i.pinimg.com/originals/e3/30/66/e33066f3cdbddd7ba3e37d2d576e8b66.jpg', 'https://i.pinimg.com/736x/b5/b2/62/b5b2620e392e74139487c209c3b03dc2.jpg',"https://i.pinimg.com/474x/fe/aa/22/feaa22b7f776fc988fb4ccbf2c539549.jpg",
  "https://i.pinimg.com/originals/c9/ea/f7/c9eaf78967ed514f730e6d161b9ee1f9.png",
  "https://i.pinimg.com/736x/26/ba/79/26ba79102b971a2da11349d7fd84fdc1.jpg",
  "https://i.pinimg.com/736x/72/2c/9b/722c9bb59f65d1d3148f1b751c8ca7d5.jpg",
  "https://i.pinimg.com/736x/6c/f3/04/6cf3041ebf6a8f7e4836c98837ea9609.jpg",
  "https://i.pinimg.com/736x/86/80/77/8680778b298641c65d81dd0d1c0ee280.jpg",
  "https://i.pinimg.com/originals/25/24/22/2524225fc756bc17f98f26d50ef342fa.jpg",
  "https://i.pinimg.com/280x280_RS/dc/6e/53/dc6e53b48dd3de659bd43257056147a6.jpg",
  "https://i.pinimg.com/736x/73/e0/fb/73e0fb7a2f1ab8a7216f076da3574d0f.jpg",
  "https://i.pinimg.com/originals/d7/a4/ac/d7a4ac159dfac1fa0ac5b0d9114a025a.jpg",
  "https://i.pinimg.com/originals/cd/ef/fc/cdeffc0bf155fe2c8c63561b437c6864.jpg"]
let lolii = loli[Math.floor(Math.random() * loli.length)]
conn.sendMessage(from, { image: { url: lolii}})
}
break      
               
           case 'neko': {
               const neko = ["https://i.pinimg.com/originals/7b/04/93/7b049307bc82190d4eef46756920455c.jpg" ,
  "https://i.pinimg.com/736x/75/1d/4b/751d4bda81598c27a15ac46874b3a305.jpg" ,
  "https://i.pinimg.com/564x/09/be/e8/09bee8b62d0f0a03fa70271993e2d651.jpg" ,
  "https://i.pinimg.com/originals/eb/a3/7b/eba37b304f19d2c6e01c44390950d216.jpg" ,
  "https://i.pinimg.com/736x/74/45/71/7445710676b96d5285bcd4ba2b1868a6.jpg" ,
  "https://i.pinimg.com/736x/01/bb/7d/01bb7d019114debf0543d006b2bd3318.jpg" ,
  "https://i.pinimg.com/originals/02/71/8e/02718ebd3f9e98416d9175ac705b4a0e.jpg" ,
  "https://i.pinimg.com/originals/4a/3f/66/4a3f6645b495908644d0cd0549af99aa.jpg" ,
  "https://i.pinimg.com/originals/18/c6/50/18c650c1bb4b5aef278154e5c10c5d08.jpg" ,
  "https://i.pinimg.com/originals/22/cd/9e/22cd9e74f3aaf505767dc21bf96e4a40.jpg" ,
  "https://i.pinimg.com/474x/c1/7f/9a/c17f9a4a4c11682ca39ab5dd00eb34c0.jpg" ,
  "https://i.pinimg.com/originals/30/5e/a8/305ea8be4fe80e5325b3f3711a4cd011.jpg" ,
  "https://i.pinimg.com/originals/11/2d/a4/112da4d48263c4f4fdc8ddc23dde70da.jpg" ,
  "https://i.pinimg.com/originals/e6/18/45/e61845b9f4d1a98950104fbcd7d1f7bd.jpg" ,
  "https://i.pinimg.com/736x/2c/8b/ba/2c8bba0b5982417813198c4f5fe45d5e.jpg" ,
  "https://i.pinimg.com/originals/52/34/d9/5234d9bc2c0efcaccde111a4dd32684e.jpg" ,
  "https://i.pinimg.com/originals/0a/36/41/0a364143adb4095a50439406f75fe4d6.jpg" ,
  "https://i.pinimg.com/originals/9f/6d/b6/9f6db6c2e51d6a87fa480b4c0ba2de7e.jpg" ,
  "https://i.pinimg.com/originals/19/d6/79/19d679f225e57b0f6732ce43180865af.png" ,
  "https://i.pinimg.com/736x/ca/87/10/ca87103c416c2f359dc30d6f3e3dfb55.jpg" ,
  "https://i.pinimg.com/originals/2e/66/45/2e6645baf0381248cc6bb9d0c5cc544d.jpg" ,
  "https://i.pinimg.com/originals/86/05/2c/86052cf86d3dd90182e748f1b9eb9173.png" ,
  "https://i.pinimg.com/736x/77/02/23/770223234b80f81e7ffb1f40edc2b027.jpg" ,
  "https://i.pinimg.com/originals/32/23/20/322320be2b7d430f5870c778c0623315.jpg"]
               let nekoo = neko[Math.floor(Math.random() * neko.length)]
               conn.sendMessage(from, { image: { url: nekoo}})
           }
               break
               
           case 'waifu':{
               const waifu =[ 
 "https://i.pinimg.com/736x/c3/53/d5/c353d5b69271d572a1b1bec8ff50f4b2.jpg" ,
 "https://i.pinimg.com/736x/40/28/4c/40284c46155cb812372e9895066b1b28.jpg" ,
 "https://i.pinimg.com/736x/52/c2/53/52c253338492f7b6185637378fefd2a1.jpg" ,
 "https://i.pinimg.com/736x/44/ed/fd/44edfde351c836c760f7db7fa75bf77c.jpg" ,
 "https://i.pinimg.com/736x/eb/72/de/eb72de9117538e2bf445a6130030abe9.jpg" ,
 "https://i.pinimg.com/originals/53/2f/f8/532ff81b4f3bc92c8db823f2cea3d7a6.jpg" ,
 "https://i.pinimg.com/originals/91/5e/47/915e47e83801b992ff66d92dc8cc1244.jpg" ,
 "https://i.pinimg.com/originals/41/2e/f3/412ef39c4244861c287675498a9c6296.png" ,
 "https://i.pinimg.com/236x/85/65/a5/8565a5a34f0bec9e6c791ed927673374.jpg" ,
 "https://i.pinimg.com/originals/89/68/6e/89686edeb4316f53832e00ea7980cf01.jpg" ,
 "https://i.pinimg.com/736x/cd/53/b0/cd53b02aec22e034be15c42d81fea760.jpg" ,
 "https://i.pinimg.com/474x/4e/62/50/4e6250d42f22d2ef37181c7ba8caf9c7.jpg" ,
 "https://i.pinimg.com/736x/d4/66/47/d466476d52f5db16f042cc660eefb66d.jpg" ,
 "https://i.pinimg.com/736x/f6/16/7f/f6167f6a8cfb2e8471bb71ccb6983ef1.jpg" ,
 "https://i.pinimg.com/736x/0d/30/ef/0d30efe3b9ba40cf6ebb67b03d27c3dc.jpg" ,
 "https://i.pinimg.com/originals/23/8d/3a/238d3abe793fcdd198efd85308f1bce9.jpg" ,
 "https://i.pinimg.com/originals/74/35/b1/7435b1c713e956dd946c6721e19e6e14.jpg" ,
 "https://i.pinimg.com/564x/c4/cf/10/c4cf101520d8fe3329dbef541e75b69a.jpg" ,
 "https://i.pinimg.com/originals/e6/96/63/e69663c0f775438826c62e02c8b8eac8.jpg" ,
 "https://i.pinimg.com/originals/15/d1/c5/15d1c53899bafb2fd4b06b66bb6deb50.jpg" ,
 "https://i.pinimg.com/originals/8f/31/17/8f31178899d16701c0764cda76430433.png" ,
 "https://i.pinimg.com/originals/1d/a6/1a/1da61a5df4a31dd394758b035b17320e.jpg" ,
 "https://i.pinimg.com/736x/43/88/c8/4388c8f657e25e192b65dab3dea1818b.jpg" ,
 "https://i.pinimg.com/originals/42/e2/2c/42e22c72db81ff2c2900badfea2aaad1.jpg" ,
 "https://i.pinimg.com/originals/b6/03/80/b6038086c1c26c47f84c1f73851e74b2.jpg" ,
 "https://i.pinimg.com/736x/15/d9/f6/15d9f667d54648b378704e0db83d00cf.jpg" ,
 "https://i.pinimg.com/736x/3c/53/3e/3c533ee5fd2eb2bc09bf22537f41f340.jpg" ,
 "https://i.pinimg.com/originals/b6/32/dd/b632dd5f206d8295e4dfdac93411e75c.jpg" ,
 "https://i.pinimg.com/originals/a4/f2/ce/a4f2cec43267f37efd7cca541385d706.jpg" ,
 "https://i.pinimg.com/564x/8c/b8/c6/8cb8c6f4ccf92a35b0afe18484233106.jpg" ,
 "https://i.pinimg.com/736x/e8/78/42/e87842875dda5f9ff0aea490bd95088a.jpg" ,
 "https://i.pinimg.com/736x/d6/e5/9d/d6e59dae68d18854a857371ba2dc1ddd.jpg" ,
 "https://i.pinimg.com/236x/e0/0a/85/e00a85d7e42f81b5ab0caea47bbb827a.jpg" ,
 "https://i.pinimg.com/originals/ce/4f/4b/ce4f4b7635e8c8ab5c8db2911edd4249.jpg" ,
 "https://i.pinimg.com/originals/54/2a/01/542a017e6b4b677bc5d79f5bb8943476.jpg" ,
 "https://i.pinimg.com/originals/b5/7d/54/b57d54e40df741ddd37adbb0de41e004.jpg" ,
 "https://i.pinimg.com/originals/12/e5/35/12e535a4c8da2694f22809eb456886e9.png" ,
 "https://i.pinimg.com/originals/eb/74/1b/eb741b162e3255172bac9f19fa40d06c.jpg" ,
 "https://i.pinimg.com/736x/40/99/45/409945e40138e0ce9aca128adf8b39e4.jpg" ]
               let waipu = waifu[Math.floor(Math.random() * waifu.length)]
               conn.sendMessage(from, { image: {url: waipu}})
           }
               break
       //TOOLS
       case 'lirik':
	   case 'liriklagu': {
	   const fg = require('api-dylux')
       let teks = text ? text : m.quoted && m.quoted.text ? m.quoted.text : ''
       if (!teks) return reply(`Want to Find What Song Lyrics?`)
       reply(mess.wait)
       try {
       let res = await fg.lyrics(text);
       let mes = `
• *${res.title}*
• *${res.artist}*      
${res.lyrics}`;
       conn.sendFile(m.chat, res.thumb, 'img.png', mes, m);
       } catch (e) {
       reply(mess.lv)
       } 
       }
       break
       
       case "s":
       case "sticker":
       case 'stiker':
       case 'swm':
       case 'take':
       case 'wm': {
       if (!quoted) return reply('mana?')
       if (quoted.isAnimated) {
       let media = await conn.downloadAndSaveMediaMessage(quoted)
       let webpToMp4 = await webp2mp4File(media)
       let encmedia = await conn.sendVideoAsSticker(m.chat, webpToMp4.result, m, {
       packname: text.split('|')[0] ? text.split('|')[0] : pushname,
       author: text.split('|')[1] ? text.split('|')[1] : ''
       })
       await fs.unlinkSync(encmedia)
       } else if (/image/.test(mime)) {
       let media = await quoted.download()
       let encmedia = await conn.sendImageAsSticker(m.chat, media, m, {
       packname: text.split('|')[0] ? text.split('|')[0] : pushname,
       author: text.split('|')[1] ? text.split('|')[1] : ''
       })
       await fs.unlinkSync(encmedia)
       } else if (/video/.test(mime)) {
       if ((quoted.msg || quoted).seconds > 11) return reply(lang.NoToStik(prefix, command))
       let media = await quoted.download()
       let encmedia = await conn.sendVideoAsSticker(m.chat, media, m, {
       packname: text.split('|')[0] ? text.split('|')[0] : pushname,
       author: text.split('|')[1] ? text.split('|')[1] : ''
       })
       await fs.unlinkSync(encmedia)
       } else {
       reply('Reply Photo Or Video You Want to Be Used as a Sticker')
       }
       }
       break
       
       case 'hd': case 'remini': {
                
			if (!quoted) return reply(`Where is the picture?`)
			if (!/image/.test(mime)) return reply(`Send/Reply Photos With Captions ${prefix + command}`)
			const { remini } = require('../src/lib/remini.js')
			let media = await quoted.download()
			let proses = await remini(media, "enhance")
			conn.sendMessage(m.chat, { image: proses, caption: `Keren kan`}, { quoted: m})
			}
			break      
               
       case 'smeme': {
	   let respond = `Send/reply image/sticker with caption ${prefix + command} text1|text2`
	   if (!/image/.test(mime)) return m.reply(respond)
       if (!text) return m.reply(respond)
       m.reply(mess.wait)
       atas = text.split('|')[0] ? text.split('|')[0] : '-'
       bawah = text.split('|')[1] ? text.split('|')[1] : '-'
	   let dwnld = await conn.downloadAndSaveMediaMessage(quoted)
	   let connCans = await TelegraPh(dwnld)
	   let smeme = `https://api.memegen.link/images/custom/${encodeURIComponent(bawah)}/${encodeURIComponent(atas)}.png?background=${connCans}`
	   let Fauzi = await conn.sendImageAsSticker(m.chat, smeme, m, { packname: global.packname, author: global.auhor })
	   await fs.unlinkSync(Fauzi)
       }
	   break
	  
       case 'pin': case 'pinterest': {
let { pinterest } = require('../src/lib/scraper')
anu = await pinterest(text)
result = anu[Math.floor(Math.random() * anu.length)]
conn.sendMessage(from, {image: { url: result }, caption: `Selamat menikmati`},{quoted:m})
}
break        
               
       case 'qc': {
       const { quote } = require('../src/lib/quote.js')
       if (!q) return reply('Enter text')
       let ppnyauser = await conn.profilePictureUrl(m.sender, 'image').catch(_=> 'https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png?q=60')
       const rest = await quote(q, pushname, ppnyauser)
       reply(mess.wait)
       await conn.sendImageAsSticker(m.chat, rest.result, m, { packname: `${global.packname}`, author: `${global.author}`})
       }
       break
            
       case 'qcimg': {
       const { quote } = require('../src/lib/quote.js')
       if (!q) return reply('Text Input')
       let ppnyauser = await conn.profilePictureUrl(m.sender, 'image').catch(_=> 'https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png?q=60')
       const rest = await quote(q, pushname, ppnyauser)
       reply(mess.wait)
       //conn.sendMessage(m.chat, { image: { url: rest.result }, caption: `Done?`}, {quoted: m})
       await conn.sendFile(m.chat, rest.result, 'img.jpg', `Don't forget to donate to support me`, ftoko)
       }
       break
	   
	   //DOWNLOADER
       case 'mediafire':
        if (!q) return reply(`Where is the link?`)
        if (!isUrl(args[0]) && !args[0].includes('mediafire.com')) return reply('The link you sent is not a mediafire link or the link is invalid!')
        reply(mess.wait)
        let medfr = await scp1.mediafire(q)
        await conn.sendMessage(from, {document:{url:medfr.link},jpegThumbnail : pp_bot, fileName:`Downloaded By ${m.pushName}.${medfr.mime}`, mimetype:`application/${mime}`},{quoted:m})
        break
               
       case 'spotify':
        if (!text) return reply(`Where is the link?`)
                const Spotify = require('../src/lib/spotify.js')
                const spotify = new Spotify(text)
                const info = await spotify.getInfo()
                if ((info).error) return reply(`The link you provided is not spotify link`)
                const { name, artists, album_name, release_date, cover_url } = info
                const details = `${ta} *Title:* ${name || ''}\n${ta} *Artists:* ${(artists || []).join(
                    ','
                )}\n${ta} *Album:* ${album_name}\n${ta} *Release Date:* ${release_date || ''}`
               const response = await conn.sendMessage(m.chat, { image: { url: cover_url }, caption: details }, { quoted: m })
                const bufferpotify = await spotify.download()
                await conn.sendMessage(m.chat, { audio: bufferpotify }, { quoted: response })
        break  
               
        case 'git': case 'gitclone':
if (!args[0]) return reply(`Where is the link?\nExample :\n${prefix}${command} https://github.com/ChataOfc/nakanonino`)
if (!isUrl(args[0]) && !args[0].includes('github.com')) return reply(`Link invalid!!`)
let regex1 = /(?:https|git)(?::\/\/|@)github\.com[\/:]([^\/:]+)\/(.+)/i
    let [, user, repo] = args[0].match(regex1) || []
    repo = repo.replace(/.git$/, '')
    let url = `https://api.github.com/repos/${user}/${repo}/zipball`
    let filename = (await fetch(url, {method: 'HEAD'})).headers.get('content-disposition').match(/attachment; filename=(.*)/)[1]
    conn.sendMessage(m.chat, { document: { url: url }, fileName: filename+'.zip', mimetype: 'application/zip' }, { quoted: m }).catch((err) => reply('error'))
break
               
	   case 'play':
       if (!text) throw 'Enter Title / Link From YouTube!';
       reply(mess.wait) 
       try {
       var search = await youtube(text);
       var convert = search.videos[0];
       if (!convert) throw 'Video/Audio not found';
       if (convert.seconds >= 3600) {
       return reply('Video is longer than 1 hour!');
       } else {
       var audioUrl
       try {
       audioUrl = `https://aemt.me/downloadAudio?URL=${convert.url}&videoName=ytdl`
       } catch (e) {
       audioUrl = `https://yt.tioo.eu.org/youtube?url=${convert.url}&filter=audioonly&quality=highestaudio&contenttype=audio/mpeg`
       }
       var build = await fetch(convert.image)
       var buffer = await build.buffer()
       var image = await uploadImage(buffer)
       var caption = `∘ Title : ${convert.title}\n∘ Ext : Search\n∘ ID : ${convert.videoId}\n∘ Duration : ${convert.timestamp}\n∘ Viewers : ${convert.views}\n∘ Upload At : ${convert.ago}\n∘ Author : ${convert.author.name}\n∘ Channel : ${convert.author.url}\n∘ Url : ${convert.url}\n∘ Description : ${convert.description}\n∘ Thumbnail: ${image}`;
       var pesan = conn.relayMessage(m.chat, { extendedTextMessage:{ text: caption, contextInfo: { externalAdReply: { title: "Powered by", mediaType: 1, previewType: 0, renderLargerThumbnail: true,thumbnailUrl: image, sourceUrl: `${convert.url}` }}, mentions: [m.sender]}}, {})
       conn.sendMessage(from, { audio: { url: audioUrl }, mimetype: "audio/mpeg", contextInfo: { externalAdReply: {
title: `${convert.title}`,
body: `${convert.author.name}`,
thumbnail: ``,
mediaType: 1,
thumbnailUrl: `${convert.image}`,
renderLargerThumbnail: true,
sourceUrl: `https://whatsapp.com/channel/0029VaGJcol1t90fUNWmkY0s`,}}}, { quoted: fkontak });
       }
       } catch (e) {
       reply(`*Error:* ` + e);
       } 
       break
	   
       case 'tiktok':
case 'tt': {
  if (!text) return errorReply(`Contoh: ${prefix + command} link`);
  reply(mess.wait);
  try {
  const data = await fetchJson(`https://skizo.tech/api/tiktok?url=${encodeURIComponent(text)}&apikey=dzsyabotz`);
    const videoUrl = data.data.play;
    const authorNickname = data.data.author ? data.data.author.nickname : "Author None";
    const videoTitle = data.data ? data.data.title : "Judul Video Tidak Tersedia";
    const videoDuration = data.data ? data.data.duration : "Durasi Video Tidak Tersedia";
    const videoCaption = `*Author* : ${authorNickname}\n*judul* : ${videoTitle}\n*Durasi* : ${videoDuration}` || "videonya kak";

    conn.sendMessage(m.chat, { caption: videoCaption, video: { url: videoUrl } }, { quoted: m });
	} catch (e) {
	 reply(`Maap sedang error silakan coba lagi`)            
	}
}
break;

               case 'ytmp4': {
                if (!q) return reply('where is the link')
                let data = await fetchJson(`https://api.zahwazein.xyz/downloader/youtube?apikey=zenzkey_3ea6f9ad84&url=${q}`)
                let txt = `\`\`\`YOUTUBE MP4\`\`\`\n\n`
                txt += `• Title : *${data.result.title}*\n`
                txt += `• Duration : *${data.result.duration}*\n`
                txt += `• Size : *${data.result.getVideo.formattedSize}*\n`
                txt += `• Resolution : *${data.result.getVideo.quality}*\n\n`
                txt += `Copy the link above and type the .ytmp3 link for audio.`
                await conn.sendMessage(m.chat, {
                    document: {
                        url: data.result.getVideo.url
                    },
                    mimetype: 'video/mp4',
                    fileName: "Downloader YtMp4.mp4",
                    caption: txt,
                    contextInfo: {
                        externalAdReply: {
                            showAdAttribution: true,
                            title: `${namabot}`,
                            body: 'PujayNet',
                            thumbnailUrl: 'https://telegra.ph/file/01c21255e501e06344ef1.png',
                            sourceUrl: `https://chat.whatsapp.com/B9xogRYJn5OHOeoEw8YkgU`,
                            mediaType: 1,
                            renderLargerThumbnail: true
                        }
                    }
                }, {
                    quoted: m
                })
                }
                break
            case 'ytmp3': {
                if (!q) return reply('where is the link')
                let data = await fetchJson(`https://api.zahwazein.xyz/downloader/youtube?apikey=zenzkey_3ea6f9ad84&url=${q}`)
conn.sendMessage(m.chat, {
                    audio: {
                        url: data.result.getVideo.url
                    },
                    mimetype: 'audio/mp4'
                }, {
                    quoted: m
                })
            }
            break
       case 'ttmp3':
       case 'tiktokmp3':
       case 'tiktokaudio':{
       if (!text) return reply( `Example : ${prefix + command} link`)
       if (!q.includes('tiktok')) return reply(`Link Invalid!!`)
       reply(mess.wait)
       require('../src/lib/tiktok').Tiktok(q).then( data => {
       conn.sendMessage(m.chat, { audio: { url: data.audio }, mimetype: 'audio/mp4' }, { quoted: m }
       )})
       }
        break 
               
                case 'getpp':
       case 'getprofile':
       case 'getppuser': {
       try {
       let who
       reply(mess.wait) 
       if (m.isGroup) who = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted.sender
       else who = m.quoted.sender ? m.quoted.sender : m.sender
       let pp = await conn.profilePictureUrl(who, 'image').catch((_) => "https://telegra.ph/file/24fa902ead26340f3df2c.png")
       conn.sendFile(m.chat, pp, "nih bang.png", 'Here you go', m, {jpegThumbnail: await(await fetch(pp)).buffer()})
       } catch {
       let sender = m.sender
       let pp = await conn.profilePictureUrl(sender, 'image').catch((_) => "https://telegra.ph/file/24fa902ead26340f3df2c.png")
       conn.sendFile(m.chat, pp, 'ppsad.png', "Tuhh v:", m, {jpegThumbnail: await(await fetch(pp)).buffer()})
       }
       }
       break
       
       
       default:
       if ( isCmd) {
	   	  reply(`Command belum tersedia, coba beberapa hari kedepan yaa! _^`)
	   }
       if (budy.startsWith(">")) {
       if (!isCreator) return;
       try {
          let evaled = await eval(budy.slice(2));
             if (typeof evaled !== "string")
                evaled = require("util").inspect(evaled);
                    await reply(evaled);
                } catch (err) {
                    await m.reply(util.format(err));
                }
            }
        }
    } catch (err) {
        m.reply(util.format(err))
    }
}