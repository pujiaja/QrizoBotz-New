const fs = require("fs");

global.apikey = "";

global.namalu = "PujayNet";
global.namabot = "QrizoBozt"; 
global.namaowner = "PujayNet";
global.packname = namabot; 
global.author = namaowner; 
global.myweb = "https://pujimods.epizy.com"; 
global.footer_text = namalu;
global.footertaa = "Pujay"
global.pp_bot = fs.readFileSync("./src/media/misaki.jpg"); 
global.owner = ["6285727882445"];
global.sessionName = "session"; 
global.gc = "https://chat.whatsapp.com/IRhyTeTi6u7GmUlklQ8bNe"; 
global.background = "https://telegra.ph/file/5361453b7995459b67357.jpg";


// MEDIA
global.taavideo = fs.readFileSync('./src/media/vidmenu.mp4')
global.taavideo2 = fs.readFileSync('./src/media/taavideo2.mp4')
global.thum = "https://telegra.ph/file/01c21255e501e06344ef1.png"
global.taaimage = fs.readFileSync('./src/media/misaki.jpg')

// SYMBOL
global.ta = "•"
global.taa = "⌕"
global.o1 = "┏❏═┅═━–〈 "
global.o2 = "┊◦"
global.o3 = "┗ ─── ─ ─ — – –"
global.s1 = "‿︵‿︵୨˚̣̣̣͙୧ "
global.s2 = " ୨˚̣̣̣͙୧‿︵‿︵"
global.s3 = "・❥"
global.s4 = "︶꒦꒷꒦꒷꒦꒷♡꒦꒷꒦꒷꒦︶"
global.footer = '▬▭▬ ▬▭▬ 𝗧𝚊𝚊𝗢𝚏𝚌 ▬▭▬ ▬▭▬'
